<?php
include_once 'Database.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $teacher_id = $_SESSION['teacher_id'];
    $student_id = $_POST['student_id'];
    $feedback_text = $_POST['feedback_text'];

    $db = Database::getInstance();
    $sql = "INSERT INTO feedback (teacher_id, student_id, feedback_text) VALUES (?, ?, ?)";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("iis", $teacher_id, $student_id, $feedback_text);

    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Feedback sent successfully!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error sending feedback!</div>";
    }
}
?>

<form method="POST" action="add_feedback.php">
    <label for="student_id">Student</label>
    <select name="student_id" required>
        <!-- Fetch students -->
        <?php
        $sql = "SELECT * FROM students";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
        }
        ?>
    </select>

    <label for="feedback_text">Feedback</label>
    <textarea name="feedback_text" required></textarea>

    <button type="submit">Send Feedback</button>
</form>
