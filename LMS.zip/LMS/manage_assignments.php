<?php
include_once 'Database.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $teacher_id = $_SESSION['teacher_id'];
    $course_id = $_POST['course_id'];
    $assignment_title = $_POST['assignment_title'];
    $assignment_description = $_POST['assignment_description'];
    $due_date = $_POST['due_date'];

    $db = Database::getInstance();

    $stmt = $db->prepare("INSERT INTO assignments (course_id, teacher_id, title, description, due_date)
        VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE description = VALUES(description), due_date = VALUES(due_date)");
    $stmt->bind_param("iisss", $course_id, $teacher_id, $assignment_title, $assignment_description, $due_date);

    if ($stmt->execute()) {
        echo "Assignment saved successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
