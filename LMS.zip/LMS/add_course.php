<?php
// Include the database connection file
include_once 'Database.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $course_id = $_POST['course_id'];
    $teacher_id = $_POST['teacher_id'];
    $title = $_POST['content_title'];
    $content_type = $_POST['content_type'];
    $content_path = $_POST['content_path'];

    // Validate inputs
    if (empty($course_id) || empty($teacher_id) || empty($title) || empty($content_type) || empty($content_path)) {
        echo "<p class='text-danger'>All fields are required!</p>";
    } else {
        // Insert into database
        $db = Database::getInstance();

        // SQL query to insert course content
        $sql = "INSERT INTO course_content (course_id, teacher_id, content_title, content_type, content_path) 
                VALUES (?, ?, ?, ?, ?)";

        // Prepare statement
        $stmt = $db->prepare($sql);

        // Correct parameter types:
        // "s" for strings (course_id, title, content_type, content_path)
        // "i" for integer (teacher_id)
        $stmt->bind_param("sssss", $course_id, $teacher_id, $title, $content_type, $content_path);

        // Execute the query and check for success
        if ($stmt->execute()) {
            echo "<p class='text-success'>Content added successfully!</p>";
        } else {
            echo "<p class='text-danger'>Error: " . $stmt->error . "</p>";
        }
        
        // Close the statement
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Add Course Content</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2>Add Course Content</h2>
    <form action="add_course.php" method="POST">
        <div class="mb-3">
            <label for="course_id" class="form-label">Course ID</label>
            <input type="text" class="form-control" id="course_id" name="course_id" required>
        </div>
        <div class="mb-3">
            <label for="teacher_id" class="form-label">Teacher ID</label>
            <input type="number" class="form-control" id="teacher_id" name="teacher_id" required>
        </div>
        <div class="mb-3">
            <label for="title" class="form-label">Content Title</label>
            <input type="text" class="form-control" id="content_title" name="content_title" required>
        </div>
        <div class="mb-3">
            <label for="content_type" class="form-label">Content Type</label>
            <select class="form-control" id="content_type" name="content_type" required>
                <option value="link">Link</option>
                <option value="pdf">PDF</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="content_path" class="form-label">Content Path</label>
            <input type="text" class="form-control" id="content_path" name="content_path" required>
        </div>
        <button type="submit" class="btn btn-primary">Add Content</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
