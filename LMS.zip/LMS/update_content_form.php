<?php
// update_content_form.php
include_once 'Database.php';
session_start();

// Fetch content title from the GET request
if (!isset($_GET['content_title'])) {
    echo "No content title selected.";
    exit;
}

$content_title = $_GET['content_title'];
$teacher_id = $_SESSION['teacher_id'];  // Teacher ID
$db = Database::getInstance();

// Fetch the content details from the database
$stmt = $db->prepare("SELECT * FROM course_content WHERE content_title = ? AND teacher_id = ?");
$stmt->bind_param("si", $content_title, $teacher_id);
$stmt->execute();
$result = $stmt->get_result();

$content = $result->fetch_assoc();
if (!$content) {
    echo "Content not found for this teacher.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Update Course Content</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">

<div class="container">
    <h2>Update Course Content</h2>
    <form method="post" action="process_update_content.php">
        <!-- Hidden field to keep the original content title -->
        <input type="hidden" name="original_title" value="<?= htmlspecialchars($content['content_title']) ?>">

        <div class="mb-3">
            <label for="course_id" class="form-label">Course ID</label>
            <input type="text" name="course_id" class="form-control" value="<?= htmlspecialchars($content['course_id']) ?>" required>
        </div>

        <div class="mb-3">
            <label for="teacher_id" class="form-label">Teacher ID</label>
            <input type="number" name="teacher_id" class="form-control" value="<?= htmlspecialchars($content['teacher_id']) ?>" required>
        </div>

        <div class="mb-3">
            <label for="content_title" class="form-label">Content Title</label>
            <input type="text" name="content_title" class="form-control" value="<?= htmlspecialchars($content['content_title']) ?>" required>
        </div>

        <div class="mb-3">
            <label for="content_type" class="form-label">Content Type</label>
            <select name="content_type" class="form-select" required>
                <option value="link" <?= $content['content_type'] == 'link' ? 'selected' : '' ?>>Link</option>
                <option value="pdf" <?= $content['content_type'] == 'pdf' ? 'selected' : '' ?>>PDF</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="content_path" class="form-label">Content Path</label>
            <input type="text" name="content_path" class="form-control" value="<?= htmlspecialchars($content['content_path']) ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Update Content</button>
    </form>
</div>

</body>
</html>