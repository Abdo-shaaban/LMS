<?php
// process_update_content.php
include_once 'Database.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $original_title = $_POST['original_title']; // Content title to update
    $course_id = $_POST['course_id'];
    $teacher_id = $_POST['teacher_id'];
    $new_title = $_POST['content_title'];
    $content_type = $_POST['content_type'];
    $content_path = $_POST['content_path'];

    // Connect to the database
    $db = Database::getInstance();

    // Update the content in the database
    $stmt = $db->prepare("UPDATE course_content SET 
        course_id = ?, 
        teacher_id = ?, 
        content_title = ?, 
        content_type = ?, 
        content_path = ?, 
        updated_at = CURRENT_TIMESTAMP
        WHERE content_title = ? AND teacher_id = ?");
        
    $stmt->bind_param("sissssi", $course_id, $teacher_id, $new_title, $content_type, $content_path, $original_title, $teacher_id);

    if ($stmt->execute()) {
        echo "<div class='alert alert-success m-4'>Content updated successfully. <a href='teacher_dashboard.php'>Back to Dashboard</a></div>";
    } else {
        echo "<div class='alert alert-danger m-4'>Error: " . $stmt->error . "</div>";
    }
}
?>
