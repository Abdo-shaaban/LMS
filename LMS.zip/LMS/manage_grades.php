<?php
include_once 'Database.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = $_POST['student_id'];
    $course_id = $_POST['course_id'];
    $grade = $_POST['grade'];

    $db = Database::getInstance();

    $stmt = $db->prepare("INSERT INTO grades (student_id, course_id, grade) 
        VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE grade = ?");
    $stmt->bind_param("iisd", $student_id, $course_id, $grade, $grade);

    if ($stmt->execute()) {
        echo "Grade saved successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
