<?php
// Include the database connection file
include_once 'Database.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $content_title = $_POST['content_title'];

    // Validate input
    if (empty($content_title)) {
        echo "<p class='text-danger'>Please select a content title to delete!</p>";
    } else {
        $db = Database::getInstance();

        // Delete using content_title
        $sql = "DELETE FROM course_content WHERE content_title = ?";
        $stmt = $db->prepare($sql);
        $stmt->bind_param("s", $content_title);

        if ($stmt->execute()) {
            echo "<p class='text-success'>Content titled '<strong>" . htmlspecialchars($content_title) . "</strong>' deleted successfully!</p>";
        } else {
            echo "<p class='text-danger'>Error deleting content: " . $stmt->error . "</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Delete Course Content</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
  <h2>Delete Course Content</h2>

  <form method="POST" action="delete_course.php">
    <div class="mb-3">
      <label for="content_title" class="form-label">Select Content Title</label>
      <select name="content_title" id="content_title" class="form-select" required>
        <option value="">-- Choose Content Title --</option>
        <?php
        // Fetch available content titles
        $db = Database::getInstance();
        $sql = "SELECT DISTINCT content_title FROM course_content";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            echo "<option value='" . htmlspecialchars($row['content_title']) . "'>" . htmlspecialchars($row['content_title']) . "</option>";
        }
        ?>
      </select>
    </div>
    <button type="submit" class="btn btn-danger">Delete</button>
    <a href="teacher_dashboard.php" class="btn btn-secondary">Cancel</a>
  </form>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
