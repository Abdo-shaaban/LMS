<?php
// Include the database connection file
include_once 'Database.php';

// Fetch teacher id (assuming you have a session or some method to get it)
session_start();
$_SESSION['teacher_id'] = 101;

// Fetch course content from the database
$db = Database::getInstance();
$sql = "SELECT * FROM course_content WHERE teacher_id = ?";
$stmt = $db->prepare($sql);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Teacher Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
</head>
<body class="light-mode">

<div class="d-flex" id="wrapper">
  <!-- Sidebar -->
  <nav id="sidebar-wrapper">
    <h4>Teacher Panel</h4>
    <ul>
      <li><a href="#course">Course Content</a></li>
      <li><a href="#materials">Learning Material</a></li>
      <li><a href="#grades">Grading</a></li>
      <li><a href="#exams">Exams</a></li>
      <li><a href="#feedback">Feedback</a></li>
      <li><a href="#assignments">Assignments</a></li>
      <li><a href="#profile">Profile</a></li>
    </ul>
    <button class="btn btn-sm btn-light mt-3" id="toggleThemeBtn">Toggle Theme</button>
  </nav>

  <!-- Page Content -->
  <main id="page-content-wrapper" class="p-4">
    <section id="course">
      <h2>Course Content</h2>
      <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#manageCourseModal">Manage Course Content</button>

      <?php
      // Display course content if any
      if ($result->num_rows > 0) {
        echo "<table class='table mt-4'>
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>";

        while ($row = $result->fetch_assoc()) {
          echo "<tr>
                  <td>" . htmlspecialchars($row['content_title']) . "</td>
                  <td>" . htmlspecialchars($row['content_type']) . "</td>
                  <td>
                    <a href='update_course.php?id=" . $row['id'] . "' class='btn btn-warning btn-sm'>Edit</a>
                    <a href='delete_course.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm'>Delete</a>
                  </td>
                </tr>";
        }

        echo "</tbody></table>";
      } else {
        echo "<p>No course content found. Please add some.</p>";
      }
      ?>
    </section>
    <hr>

    <section id="materials">
  <h2>Learning Material</h2>
  <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#uploadMaterialModal">Upload Material</button>

  <?php if (!empty($materials_by_course)): ?>
    <?php foreach ($materials_by_course as $course_title => $materials): ?>
      <div class="card mb-3">
        <div class="card-header bg-primary text-white">
          <?php echo htmlspecialchars($course_title); ?>
        </div>
        <ul class="list-group list-group-flush">
          <?php foreach ($materials as $mat): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              <?php echo htmlspecialchars($mat['material_title']); ?>
              <a href="<?php echo htmlspecialchars($mat['file_path']); ?>" class="btn btn-sm btn-outline-secondary" target="_blank">Download</a>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <p>No learning materials uploaded yet.</p>
  <?php endif; ?>
</section>

    <hr>

    <section id="grades">
      <h2>Grading</h2>
      <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#gradeModal">Manage Grades</button>
    </section>
    <hr>

    <section id="exams">
      <h2>Exams</h2>
      <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#examModal">Upload Exam</button>
    </section>
    <hr>

    <section id="feedback">
      <h2>Feedback</h2>
      <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#feedbackModal">Send Feedback</button>
    </section>
    <hr>

    <section id="assignments">
      <h2>Assignments</h2>
      <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#assignmentModal">Manage Assignments</button>
    </section>
    <hr>

    <section id="profile">
      <h2>Profile</h2>
      <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#profileModal">Edit Profile</button>
    </section>
  </main>
</div>

<!-- Manage Course Content Modal -->
<div class="modal fade" id="manageCourseModal" tabindex="-1" aria-labelledby="manageCourseModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="manageCourseModalLabel">Manage Course Content</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>What would you like to do?</p>
        <div class="d-flex justify-content-around">
          <a href="add_course.php" class="btn btn-success">Add Content</a>
          <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteCourseModal">Delete Content</button>
          <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#updateCourseModal">Update Content</button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Delete Course Modal -->
<!-- Delete Course Modal -->
<div class="modal fade" id="deleteCourseModal" tabindex="-1" aria-labelledby="deleteCourseModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteCourseModalLabel">Delete Course Content</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="delete_course.php" method="POST">
          <div class="mb-3">
            <label for="content_title_to_delete" class="form-label">Enter Course Title to Delete</label>
            <input type="text" class="form-control" id="content_title_to_delete" name="content_title_to_delete" required>
          </div>
          <button type="submit" class="btn btn-danger">Delete Content</button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Update Content Modal -->
<div class="modal fade" id="updateCourseModal" tabindex="-1" aria-labelledby="updateCourseModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="updateCourseModalLabel">Update Course Content</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="update_content_form.php" method="GET">
          <div class="mb-3">
            <label for="content_title_to_update" class="form-label">Select Course Title to Update</label>
            <select name="content_title" class="form-select" id="content_title_to_update" required>
              <option value="">-- Select Content Title --</option>
              <?php
                // Fetch content titles for the teacher
                $teacher_id = $_SESSION['teacher_id'];  // Teacher ID
                $sql = "SELECT DISTINCT content_title FROM course_content WHERE teacher_id = ?";
                $stmt = $db->prepare($sql);
                $stmt->bind_param("i", $teacher_id);
                $stmt->execute();
                $result = $stmt->get_result();

                // Display content titles in the dropdown
                while ($row = $result->fetch_assoc()) {
                  echo "<option value='" . htmlspecialchars($row['content_title']) . "'>" . htmlspecialchars($row['content_title']) . "</option>";
                }
              ?>
            </select>
          </div>
          <button type="submit" class="btn btn-warning">Next</button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Grade Modal -->
<div class="modal fade" id="gradeModal" tabindex="-1" aria-labelledby="gradeModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="manage_grades.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="gradeModalLabel">Manage Grades</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label for="student_id" class="form-label">Student ID</label>
          <input type="number" name="student_id" class="form-control" required>
        </div>
        <div class="mb-3">
          <label for="course_id" class="form-label">Course ID</label>
          <input type="number" name="course_id" class="form-control" required>
        </div>
        <div class="mb-3">
          <label for="grade" class="form-label">Grade</label>
          <input type="text" name="grade" class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">Submit Grade</button>
      </div>
    </form>
  </div>
</div>

<!-- Exam Modal -->
<div class="modal fade" id="examModal" tabindex="-1" aria-labelledby="examModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="upload_exam.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="examModalLabel">Upload Exam</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label for="course_id" class="form-label">Course ID</label>
          <input type="number" name="course_id" class="form-control" required>
        </div>
        <div class="mb-3">
          <label for="exam_title" class="form-label">Exam Title</label>
          <input type="text" name="exam_title" class="form-control" required>
        </div>
        <div class="mb-3">
          <label for="exam_description" class="form-label">Description</label>
          <textarea name="exam_description" class="form-control" rows="3" required></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">Upload Exam</button>
      </div>
    </form>
  </div>
</div>

<!-- Feedback Modal -->
<div class="modal fade" id="feedbackModal" tabindex="-1" aria-labelledby="feedbackModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="send_feedback.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="feedbackModalLabel">Send Feedback</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label for="student_id" class="form-label">Student ID</label>
          <input type="number" name="student_id" class="form-control" required>
        </div>
        <div class="mb-3">
          <label for="feedback" class="form-label">Feedback</label>
          <textarea name="feedback" class="form-control" rows="3" required></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">Send Feedback</button>
      </div>
    </form>
  </div>
</div>

<!-- Assignment Modal -->
<div class="modal fade" id="assignmentModal" tabindex="-1" aria-labelledby="assignmentModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="manage_assignments.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="assignmentModalLabel">Manage Assignments</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label for="assignment_title" class="form-label">Assignment Title</label>
          <input type="text" name="assignment_title" class="form-control" required>
        </div>
        <div class="mb-3">
          <label for="course_id" class="form-label">Course ID</label>
          <input type="number" name="course_id" class="form-control" required>
        </div>
        <div class="mb-3">
          <label for="description" class="form-label">Description</label>
          <textarea name="description" class="form-control" rows="3" required></textarea>
        </div>
        <div class="mb-3">
          <label for="due_date" class="form-label">Due Date</label>
          <input type="date" name="due_date" class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">Submit Assignment</button>
      </div>
    </form>
  </div>
</div>

<!-- Upload Material Modal -->
<div class="modal fade" id="uploadMaterialModal" tabindex="-1" aria-labelledby="uploadMaterialModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="upload_material.php" method="POST" enctype="multipart/form-data" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="uploadMaterialModalLabel">Upload Learning Material</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label for="course_content_id" class="form-label">Course Content</label>
          <select name="course_content_id" class="form-select" required>
            <option value="">-- Select Course Content --</option>
            <?php
              $sql = "SELECT id, content_title FROM course_content WHERE teacher_id = ?";
              $stmt = $db->prepare($sql);
              $stmt->bind_param("i", $teacher_id);
              $stmt->execute();
              $result = $stmt->get_result();
              while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['id'] . "'>" . htmlspecialchars($row['content_title']) . "</option>";
              }
            ?>
          </select>
        </div>
        <div class="mb-3">
          <label for="material_title" class="form-label">Material Title</label>
          <input type="text" name="material_title" class="form-control" required>
        </div>
        <div class="mb-3">
          <label for="material_file" class="form-label">Choose File</label>
          <input type="file" name="material_file" class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">Upload</button>
      </div>
    </form>
  </div>
</div>


<!-- Toast Notification -->
<div class="toast-container position-fixed bottom-0 end-0 p-3">
  <div class="toast align-items-center text-bg-success border-0" id="successToast" role="alert">
    <div class="d-flex">
      <div class="toast-body">Saved successfully!</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="script.js"></script>
</body>
</html>
