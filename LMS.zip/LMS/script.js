document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("toggleThemeBtn");
  const body = document.body;

  // Load theme from localStorage
  const savedTheme = localStorage.getItem("theme");
  if (savedTheme === "dark") {
    body.classList.remove("light-mode");
    body.classList.add("dark-mode");
  }

  // Toggle theme
  toggleBtn.addEventListener("click", () => {
    body.classList.toggle("dark-mode");
    body.classList.toggle("light-mode");

    localStorage.setItem("theme", body.classList.contains("dark-mode") ? "dark" : "light");
  });

  // Form validation + toast feedback
  const forms = document.querySelectorAll("form");
  const toastEl = document.getElementById("successToast");
  const toast = new bootstrap.Toast(toastEl);

  forms.forEach(form => {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      if (form.checkValidity()) {
        toast.show();
        form.reset();
      }
    });
  });
});
