<?php
include_once 'Database.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $teacher_id = $_SESSION['teacher_id'];
    $course_id = $_POST['course_id'];
    $exam_title = $_POST['exam_title'];
    $exam_date = $_POST['exam_date'];
    $exam_file = $_FILES['exam_file']['name'];
    
    // Move the uploaded file to the server directory
    move_uploaded_file($_FILES['exam_file']['tmp_name'], "uploads/$exam_file");

    $db = Database::getInstance();
    $sql = "INSERT INTO exams (teacher_id, course_id, exam_title, exam_date, exam_file) VALUES (?, ?, ?, ?, ?)";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("iisss", $teacher_id, $course_id, $exam_title, $exam_date, $exam_file);

    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Exam added successfully!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error adding exam!</div>";
    }
}
?>

<form method="POST" enctype="multipart/form-data">
    <label for="course_id">Course</label>
    <select name="course_id" required>
        <!-- Fetch courses from database -->
        <?php
        $teacher_id = $_SESSION['teacher_id'];
        $db = Database::getInstance();
        $sql = "SELECT * FROM courses WHERE teacher_id = ?";
        $stmt = $db->prepare($sql);
        $stmt->bind_param("i", $teacher_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            echo "<option value='" . $row['id'] . "'>" . $row['course_name'] . "</option>";
        }
        ?>
    </select>

    <label for="exam_title">Exam Title</label>
    <input type="text" name="exam_title" required>

    <label for="exam_date">Exam Date</label>
    <input type="datetime-local" name="exam_date" required>

    <label for="exam_file">Upload Exam</label>
    <input type="file" name="exam_file" required>

    <button type="submit">Add Exam</button>
</form>
