<?php
include_once 'Database.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $teacher_id = $_SESSION['teacher_id'];
    $course_id = $_POST['course_id'];
    $assignment_title = $_POST['assignment_title'];
    $due_date = $_POST['due_date'];
    $assignment_file = $_FILES['assignment_file']['name'];
    
    // Move the uploaded file to the server directory
    move_uploaded_file($_FILES['assignment_file']['tmp_name'], "uploads/$assignment_file");

    $db = Database::getInstance();
    $sql = "INSERT INTO assignments (teacher_id, course_id, assignment_title, due_date, assignment_file) VALUES (?, ?, ?, ?, ?)";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("iisss", $teacher_id, $course_id, $assignment_title, $due_date, $assignment_file);

    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Assignment added successfully!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error adding assignment!</div>";
    }
}
?>

<form method="POST" enctype="multipart/form-data">
    <label for="course_id">Course</label>
    <select name="course_id" required>
        <!-- Fetch courses from database -->
        <?php
        $teacher_id = $_SESSION['teacher_id'];
        $db = Database::getInstance();
        $sql = "SELECT * FROM courses WHERE teacher_id = ?";
        $stmt = $db->prepare($sql);
        $stmt->bind_param("i", $teacher_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            echo "<option value='" . $row['id'] . "'>" . $row['course_name'] . "</option>";
        }
        ?>
    </select>

    <label for="assignment_title">Assignment Title</label>
    <input type="text" name="assignment_title" required>

    <label for="due_date">Due Date</label>
    <input type="datetime-local" name="due_date" required>

    <label for="assignment_file">Upload Assignment</label>
    <input type="file" name="assignment_file" required>

    <button type="submit">Add Assignment</button>
</form>
