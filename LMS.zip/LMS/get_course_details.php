<?php
// Include the database connection file
include_once 'Database.php';

if (isset($_GET['id'])) {
  $course_id = $_GET['id'];

  // Fetch course content based on ID
  $db = Database::getInstance();
  $sql = "SELECT * FROM course_content WHERE id = ?";
  $stmt = $db->prepare($sql);
  $stmt->bind_param("i", $course_id);
  $stmt->execute();
  $result = $stmt->get_result();
  
  if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode($row);
  } else {
    echo json_encode(['error' => 'Course not found']);
  }
}
?>
